/**
 * Family Tree Visualization JavaScript
 * D3.js visualization utilities and helpers
 */

// This file contains D3.js visualization utilities
// The main FamilyTreeVisualization class is in tree-view.js

// D3.js utility functions can be added here in the future
// For now, all visualization logic is in tree-view.js